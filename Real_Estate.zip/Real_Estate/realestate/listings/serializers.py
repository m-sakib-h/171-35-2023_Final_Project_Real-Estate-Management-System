from rest_framework import serializers
from .models import Listing


# serializers for realtor
class ListingSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Listing
        # fields=['realtor','title','address','city','state','zipcode','description','price'....]
        fields = '__all__'
