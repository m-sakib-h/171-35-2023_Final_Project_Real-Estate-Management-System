from django.urls import path, include
from . import views

from rest_framework import routers
from . import api_view

router = routers.DefaultRouter()
router.register('v1', api_view.ListingViewSet)

urlpatterns = [
    path('listings/', views.listings, name='listings'),
    path('<int:listing_id>', views.listing, name='listing'),
    path('inquiry/', views.listing_inquiry, name='listing_inquiry'),
    path('',include(router.urls)),
]
