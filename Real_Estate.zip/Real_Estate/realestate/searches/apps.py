from django.apps import AppConfig


class SearchesConfig(AppConfig):
    name = 'searches'
