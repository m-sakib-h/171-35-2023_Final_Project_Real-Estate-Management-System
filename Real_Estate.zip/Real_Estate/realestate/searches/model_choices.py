state_choice = {
    'Rangpur': 'Rangpur',
    'Chittagong': 'Chittagong',
    'Dhaka': 'Dhaka',
    'Lakshmipur': 'Lakshmipur',
    'Mohammod pur': 'Mohammod pur',
}
Bedrooms_choice = {
    '1': '1',
    '2': '2',
    '3': '3',
    '4': '4',
    '5': '5',
    '6': '6',
}
price_choice = {
    '100000': '100000',
    '120000': '120000',
    '130000': '130000',
    '140000': '140000',
    '150000': '150000',
}